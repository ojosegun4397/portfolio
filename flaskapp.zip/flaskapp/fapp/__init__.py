from flask import Flask

from flask_sqlalchemy import SQLAlchemy

app=Flask(__name__)

from fapp import config
app.config.from_pyfile('config.py', silent=False)

db=SQLAlchemy(app)









#load the routes here
from fapp import routes,config,adminroutes