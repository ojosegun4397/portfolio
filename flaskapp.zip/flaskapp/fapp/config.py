SECRET_KEY='htw7654TR2' 
APP_NAME='Class Exercise'
SQLALCHEMY_DATABASE_URI="mysql+mysqlconnector://root@localhost/realapp"