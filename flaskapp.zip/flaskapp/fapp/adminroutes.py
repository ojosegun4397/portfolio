from flask import render_template,request,redirect,flash,make_response,session
from sqlalchemy.sql import text
import re
from fapp import app,db



@app.route('/f/news', methods=['POST','GET'])
def newsletter():
    if request.method=="GET":
        return render_template('admin/newsletter.html')
    else:
        email=request.form.get('email')
        check=re.match('^[a-z | A-Z ]([a-z|A-Z|0-9]+)@[a-z|A-Z]+(.)[a-z|A-Z]+', email)
        #the raw sql method, at the top of this page, write from fapp import db
        if check:
            db.session.execute(text(f"INSERT INTO newsletter SET email='{email}'"))
            db.session.commit()
            flash('thank you for your subscription')
        else:
            flash('invalid email format')
        return redirect("/f/login")





@app.route('/f/register')
def f_register():
    return render_template("admin/layout.html")

@app.route('/f/login',methods=['POST','GET'])
def f_login():
    
    if request.method=="GET":
         return render_template("admin/flogin.html")
    else:
        name=request.form.get('username')
        password=request.form['password']
        if  password=="1234":
            flash( "registration was successful")
            session['loggedin']=name
            return redirect ('/f/profile')


        else:
            flash( "registration was not successful")
            return redirect('/f/login')


@app.route('/f/logout')
def f_logout():
    if session.get("loggedin") !=None:
         session.pop('loggedin', None)
         flash('you are logged out')
    return redirect('/f/login')

@app.route('/f/profile')
def f_profile():
    if session.get('loggedin') != None:
        return render_template("admin/fprofile.html")
    else:
        flash('you must be logged in to view this page')
        return redirect('/f/login')

@app.route('/f/dashboard')
def f_dashboard():
    if session.get('loggedin') !=None:
        return  render_template("admin/fdashboard.html")
    else:
        flash('you must log in to view this page')
        return redirect('/f/login')

